package com.company;

import java.util.*;

public class Main {

    public static void main(String[] args) {
        Student student = new Student();
        Scanner scanner = new Scanner(System.in);
        Map map = new LinkedHashMap();
        System.out.println("Enter Name:");
        String nameString = scanner.nextLine();
        student.setName(nameString);
        map.put("Name:",student.getName());
        System.out.println("Enter Student Code:");
        String codeString = scanner.nextLine();
        int code = Integer.parseInt(codeString);
        student.setStudentCode(code);
        map.put("Student Code:",student.getStudentCode());
        System.out.println("Enter Student Grade-Point Average:");
        String avgString = scanner.nextLine();
        float avg = Float.parseFloat(avgString);
        student.setGradePointAverage(avg);
        map.put("Average Point:",student.getGradePointAverage());
        Set set =map.keySet();
        for (Object o : set) {
            System.out.println(o);
            System.out.println(map.get(o));
        }
    }
}
