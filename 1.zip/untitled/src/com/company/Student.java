package com.company;

public class Student {
    private int studentCode;
    private String name;
    private float gradePointAverage;

    public void setStudentCode(int studentCode) {
        this.studentCode = studentCode;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGradePointAverage(float gradePointAverage) {
        this.gradePointAverage = gradePointAverage;
    }

    public int getStudentCode() {
        return studentCode;
    }

    public String getName() {
        return name;
    }

    public float getGradePointAverage() {
        return gradePointAverage;
    }
}
