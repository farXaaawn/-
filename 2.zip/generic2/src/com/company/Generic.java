package com.company;

    class Coordinate <FIRST, SECOND,THIRD> {
        private FIRST x;
        private SECOND y;
        private THIRD z;

        public FIRST getX() {
            return x;
        }

        public void setX(FIRST x) {
            this.x = x;
        }

        public SECOND getY() {
            return y;
        }

        public void setY(SECOND y) {
            this.y = y;
        }

        public THIRD getZ() {
            return z;
        }

        public void setZ(THIRD z) {
            this.z = z;
        }
    }