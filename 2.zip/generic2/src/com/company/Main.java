package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Coordinate coordinate = new Coordinate();

        System.out.println("Enter Username:");
        String userStr = scanner.nextLine();
        coordinate.setX(userStr);

        System.out.println("Enter Password:");
        String passStr = scanner.nextLine();
        coordinate.setY(passStr);

        System.out.println("Enter Email:");
        String emailStr = scanner.nextLine();
        coordinate.setZ(emailStr);

        Person person = new Person ();

        person.setUsername((String) coordinate.getX());
        person.setPassword((String) coordinate.getY());
        person.setEmail((String) coordinate.getZ());

        Person c1 = null;
        try {
            c1 = (Person) person.clone ();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        Person c2 =null;
        try {
            c2 = (Person) person.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        Person c3 = null;
        try {
            c3 = (Person) person.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        if(!person.equals(c1) && !person.equals(c2) && !person.equals(c3)){
            System.out.println(person);
                System.out.println("Username:" + person.getUsername());
                System.out.println("Password:" + person.getPassword() );
                System.out.println("Email:" + person.getEmail());

            System.out.println(c1);
                System.out.println("Username:" + c1.getUsername());
                System.out.println("Password:" + c1.getPassword() );
                System.out.println("Email:" + c1.getEmail());

            System.out.println(c2);
            System.out.println("Username:" + c2.getUsername());
            System.out.println("Password:" + c2.getPassword() );
            System.out.println("Email:" + c2.getEmail());

            System.out.println(c3);
                System.out.println("Username:" + c3.getUsername());
                System.out.println("Password:" + c3.getPassword() );
                System.out.println("Email:" + c3.getEmail());
        }

    }
}
